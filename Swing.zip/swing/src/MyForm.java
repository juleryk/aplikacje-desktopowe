import javax.swing.*;

public class MyForm {
    private JPanel panel1;
}

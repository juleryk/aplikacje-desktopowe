import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class FileHandler {

    String dirToRead;
    String activeFile;

     JFileChooser jFileChooser;

    public void readDirectory(String dir) {
               Set<String> files = new HashSet<>();
        try {
            DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(dir));
            for (Path path : stream){
                if (!Files.isDirectory(path)){
                    files.add(path.getFileName().toString());
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public String readFile(String input){
        String out = "";
        File file = new File(input);
        try {
            Scanner rr = new Scanner(file);
            while (rr.hasNextLine()){
                out += rr.nextLine();

            }
        } catch (FileNotFoundException e) {
            System.out.println("Brak pliku: " + input);
            throw new RuntimeException(e);
        }

        return out;

    }
    }


import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.io.*;
import java.util.ResourceBundle;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class SideBar extends JPanel implements ListSelectionListener {
    DefaultListModel data;
    JList list;
    FileHandler fn;

    SideBar() {
        this(new BorderLayout(), null);
    }

    SideBar(BorderLayout layout, FileHandler fileHandler) {
        this.fn = fileHandler;
        this.data = new DefaultListModel();
        this.list = new JList(data);

        this.setLayout(layout);
        data = new DefaultListModel();
        data.addElement("plik1.txt");
        data.addElement("plik2.txt");
        data.addElement("plik3.txt");
        data.addElement("plik4.txt");

        list = new JList(data);


        list.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        list.setLayoutOrientation(JList.VERTICAL);

        list.setSelectedIndex(2);
        list.setVisibleRowCount(4);
        list.addListSelectionListener(this);

        JScrollPane scrpList=new JScrollPane(list);

        this.add(scrpList);

    }

    @Override
    public void valueChanged(ListSelectionEvent event) {
            Object src=event.getSource();

            if(src==list){
                if(!event.getValueIsAdjusting()){
                    if(list.getSelectedIndex()!=-1){
                        String fileName=data.getElementAt(list.getSelectedIndex()).toString();
                        System.out.println(fileName);


                    }
                }
            }
    }


    public void zipFile(String fileName) {
        try {
            FileOutputStream fos = new FileOutputStream(fileName + ".zip");
            ZipOutputStream zos = new ZipOutputStream(fos);

            File file = new File(fileName);

            FileInputStream fis = new FileInputStream(file);

            zos.putNextEntry(new ZipEntry(file.getName()));

            byte[] buffer = new byte[1024];
            int length;
            while ((length = fis.read(buffer)) > 0) {
                zos.write(buffer, 0, length);
            }

            zos.closeEntry();
            fis.close();

            zos.close();
            fos.close();

            System.out.println("Plik został spakowany.");

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public String getSelectedFileName() {
        int selectedIndex = list.getSelectedIndex();
        if (selectedIndex != -1) {
            return data.getElementAt(selectedIndex).toString();
        }
        return null;
    }

    private String selectedFileName;

    public void setSelectedFileName(String fileName) {
        this.selectedFileName = fileName;
    }


}

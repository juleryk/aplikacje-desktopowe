import com.sun.deploy.nativesandbox.NativeSandboxBroker;

import javax.swing.*;
import java.util.Locale;
import java.util.ResourceBundle;

public class ChooserLang {
    private boolean chosen = false;
    private Locale newLocale;
    public ResourceBundle resBundle;

    public void choose(String tt) {
        Object[] options1 = {"Polish", "English"};

        int selectedOption = JOptionPane.showOptionDialog(null, "Choose language", tt ,
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options1, options1[0]);

        if (selectedOption == JOptionPane.YES_OPTION) {
            Locale newLocale = new Locale("pl", "pl");
            this.newLocale = newLocale;
            Locale.setDefault(newLocale);
            resBundle = ResourceBundle.getBundle("BundleLang");
        } else if (selectedOption == JOptionPane.NO_OPTION) {
            Locale newLocale = new Locale("en", "US");
            Locale.setDefault(newLocale);
            resBundle = ResourceBundle.getBundle("BundleLang", Locale.ENGLISH);
        }

        chosen = true;
    }

    public boolean hasChosen() {
        return chosen;
    }

    public ResourceBundle getResBundle() {
        return resBundle;
    }
}

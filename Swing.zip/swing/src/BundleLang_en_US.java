import java.util.ListResourceBundle;

public class BundleLang_en_US extends ListResourceBundle {

        static final Object[][] contents = {
                {"label", "Available settings"},
                {"button1", "Cancel"},
                {"button2", "Accept"},
                {"czekobox", "Run centered"},
                {"title", "Window"},
                {"save", "Save"},
                {"copy", "Copy"},
                {"paste", "Paste"},
                {"mi1", "Proporties"},
                {"open", "Open"},
                {"zip","Zipuj"}
        };
        @Override
        protected Object[][] getContents() {
            return contents;
        }
    }



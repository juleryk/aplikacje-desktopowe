import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

public class ToolBar extends JToolBar{

    JButton btnM0,btnM1,btn1,btn2,btn3,btn4,btn5;

    ToolBar(JMenuBar mb){
        JToolBar tlb=this;

        ChooserLang chooserLang = new ChooserLang();
        chooserLang.choose("ToolBar Language");
        ResourceBundle resBudle = chooserLang.resBundle;

        btnM0=new JButton("\u2630");
        btnM0.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                tlb.setVisible(!mb.isVisible());
            }
        });

        btnM1=new JButton("\u2756");
        btnM1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                tlb.setFloatable(!tlb.isFloatable());
            }
        });

        btn1=new JButton(resBudle.getString("open"));

        btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SideBar sideBar = new SideBar();
                String selectedFileName = sideBar.getSelectedFileName();
                if (selectedFileName != null) {
                    sideBar.setSelectedFileName(selectedFileName);
                    sideBar.zipFile(selectedFileName);
                }
            }
        });

        btn2=new JButton(resBudle.getString("save"));
        btn3=new JButton(resBudle.getString("copy"));
        btn4=new JButton(resBudle.getString("paste"));
        btn5=new JButton();
        btn5.setIcon(new ImageIcon(""));

        this.setFloatable(false);
        this.setRollover(true);
        this.add(btnM0);
        this.add(btnM1);
        this.add(btn1);
        this.add(btn2);
        this.addSeparator();
        this.add(btn3);
        this.add(btn4);

        add(btn5);
    }
}

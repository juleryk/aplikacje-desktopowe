import java.awt.*;
import java.util.ResourceBundle;
import javax.swing.*;

public class Frame{
        JFrame frame;

        Frame(){
            ChooserLang chooserLang = new ChooserLang();
            chooserLang.choose("Frame Language");
            ResourceBundle resBudle = chooserLang.resBundle;


            frame = new JFrame(resBudle.getString("title"));
            frame.setLayout(new BorderLayout());



            JPanel menuPanel=new JPanel();
            menuPanel.setLayout(new BorderLayout());
            MainMenu mainMenu=new MainMenu(new JFrame(),new JPanel());
            ToolBar toolBar=new ToolBar(new JMenuBar());

            menuPanel.add(mainMenu,BorderLayout.PAGE_START);
            menuPanel.add(toolBar,BorderLayout.PAGE_END);

            frame.add(menuPanel,BorderLayout.PAGE_START);

//            JPanel panel1 = new JPanel();
//            JLabel label2 = new JLabel("Dostępne ustawienia");
//            JButton button1 = new JButton("Odrzuć");
//            JButton button2 = new JButton("Zachowuj");
//            JCheckBox checkBox = new JCheckBox("Uruchom wysrodkowane");
//            String[] options = {"Pozycja 1", "Pozycja 2", "Pozycja 3", "Pozycja 4"};
//            JComboBox<String> comboBox = new JComboBox<>(options);
//            panel1.add(label2);
//            panel1.add(button1);
//            panel1.add(button2);
//            panel1.add(checkBox);
//            panel1.add(comboBox);


            JTextArea textArea1=new JTextArea(150,50);
            JScrollPane taScrollPane1=new JScrollPane(textArea1,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

            JTextArea textArea2=new JTextArea(150,50);
            JScrollPane taScrollPane2=new JScrollPane(textArea2,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

//            JScrollPane taScrollPane3 = new JScrollPane(panel1,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            JTabbedPane tabbedPane=new JTabbedPane();
            tabbedPane.addTab("pane 1",taScrollPane1);
            tabbedPane.addTab("pane 2",taScrollPane2);
//            tabbedPane.addTab("własciowości",taScrollPane3);
            frame.add(tabbedPane,BorderLayout.EAST);


            SideBar sideBar=new SideBar(new BorderLayout(), new FileHandler());
            sideBar.setPreferredSize(new Dimension(400,500));
            JScrollPane scrollPane=new JScrollPane(sideBar,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

            frame.add(scrollPane,BorderLayout.WEST);

            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setMinimumSize(new Dimension(1080,720));
            frame.setVisible(true);
            frame.pack();
        }
}

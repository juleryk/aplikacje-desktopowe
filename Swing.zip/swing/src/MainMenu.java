import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

public class MainMenu extends JMenuBar implements ActionListener {
    JFrame box;
    JPanel pnl;
    JMenu menu,submenu;
    JMenuItem mi1,mi2,mi3,mi4,mi5,mi6;
    Preferences preferences;
    private boolean statusCheckbox;
    MainMenu(JFrame box,JPanel pnl) {

        ChooserLang chooserLang = new ChooserLang();
        chooserLang.choose("Main Menu Language");
        ResourceBundle resBudle = chooserLang.resBundle;
        this.box = box;
        this.pnl = pnl;
        menu = new JMenu("Plik");
        menu.setMnemonic(KeyEvent.VK_P);
        submenu = new JMenu("TestMenu1");
        mi1 = new JMenuItem(resBudle.getString("mi1"));
        mi2 = new JMenuItem("Opcja 2");
        mi3 = new JMenuItem("Opcja 3");
        mi4 = new JMenuItem("Opcja 4");
        mi5 = new JMenuItem("Opcja 5");
        mi6 = new JMenuItem("Opcja 6");

        mi1.addActionListener(this);
        mi3.addActionListener(this);
        mi5.addActionListener(this);

        menu.add(mi1);
        menu.add(mi2);
        menu.add(mi3);
        menu.add(mi4);
        menu.add(mi5);
        menu.add(mi6);
        menu.add(submenu);

        this.add(menu);

//        Object[] options1 = {"Polish", "English"};
//        int selectedOption = JOptionPane.showOptionDialog(null, "Choose language", "<>",
//                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options1, options1[0]);
//        ResourceBundle resBudle = null;
//        if (selectedOption == JOptionPane.YES_OPTION) {
//            Locale newLocale = new Locale("pl", "pl");
//            Locale.setDefault(newLocale);
//            resBudle = ResourceBundle.getBundle("BundleLang");
//        } else if (selectedOption == JOptionPane.NO_OPTION) {
//            Locale newLocale = new Locale("en", "US");
//            Locale.setDefault(newLocale);
//            resBudle = ResourceBundle.getBundle("BundleLang", Locale.ENGLISH);
//        }


        JDialog dialog = new JDialog();
        dialog.setTitle("Dialog");
        dialog.setSize(300, 150);
        dialog.setLayout(new BoxLayout(dialog.getContentPane(), BoxLayout.PAGE_AXIS));

//        JLabel label2 = new JLabel(resBudle.getString("label"));
//        JButton button1 = new JButton(resBudle.getString("button1"));
//        JButton button2 = new JButton(resBudle.getString("button2"));
//        JCheckBox czekobox = new JCheckBox(resBudle.getString("czekobox"), false);



        JLabel label2 = new JLabel(resBudle.getString("label"));
        JButton button1 = new JButton(resBudle.getString("button1"));
        JButton button2 = new JButton(resBudle.getString("button2"));
        JCheckBox czekobox = new JCheckBox(resBudle.getString("czekobox"), false);

//        JLabel label2 = new JLabel("label");
//        JButton button1 = new JButton("button1");
//        JButton button2 = new JButton("button2");
//        JCheckBox czekobox = new JCheckBox("czekobox", false);

        preferences = Preferences.userRoot().node(this.getClass().getName());
        statusCheckbox = preferences.getBoolean("czekobox", false);
        czekobox.setSelected(statusCheckbox);


        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                statusCheckbox = czekobox.isSelected();
                preferences.putBoolean("czekobox", czekobox.isSelected());
            }
        });

        czekobox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                statusCheckbox = czekobox.isSelected();
            }
        });

        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.setVisible(false);
            }
        });

        String[] options = {"Pozycja 1", "Pozycja 2", "Pozycja 3", "Pozycja 4"};
        JComboBox<String> comboBox = new JComboBox<>(options);

        dialog.add(label2);
        dialog.add(button1);
        dialog.add(button2);
        dialog.add(czekobox);
        dialog.add(comboBox);

        mi1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.setVisible(true);
            }
        });


    }



    public void actionPerformed(ActionEvent e){
        Object src=e.getSource();

        if(src==mi1){
            pnl.setBackground(Color.RED);
        }
        if(src==mi2){
            pnl.setBackground(Color.GREEN);
        }
        if(src==mi3){
            pnl.setBackground(Color.BLUE);
        }
        if(src==mi4){
            pnl.setBackground(Color.WHITE);
        }
        if(src==mi5){
            box.dispose();
        }
    }


}

import java.util.Date;
import java.util.ListResourceBundle;

public class BundleLang extends ListResourceBundle {

        static final Object[][] contents = {
                {"label", "Dostępne ustawienia"},
                {"button1", "Odrzuć"},
                {"button2", "Zachowuj"},
                {"czekobox", "Uruchom wysrodkowane"},
                {"title", "Okno"},
                {"save", "Zapisz"},
                {"copy", "Kopiuj"},
                {"paste", "Wklej"},
                {"mi1", "Własciowości"},
                {"open", "Otwórz"},
                {"zip","Zipuj"}
        };
        @Override
        protected Object[][] getContents() {
            return contents;
        }
    }


